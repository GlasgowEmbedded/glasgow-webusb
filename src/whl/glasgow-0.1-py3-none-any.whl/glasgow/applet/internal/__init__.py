"""
The ``internal`` taxon groups applets operating on Glasgow itself.
"""
