from amaranth import *
from amaranth.lib import data, wiring, io


__all__ = ["MultiplexedPort"]


class MultiplexedPort(PortLike):
    """Represents a multiplexed library I/O port.

    Implements the :class:`PortLike` interface.

    Parameters
    ----------
    direction : :class:`Direction` or :class:`str`
        Set of allowed buffer directions. A string is converted to a :class:`Direction` first.
        If equal to :attr:`~io.Direction.Input` or :attr:`~io.Direction.Output`, this port can only be
        used with buffers of matching direction. If equal to :attr:`~io.Direction.Bidir`, this port
        can be used with buffers of any direction.
    width : :class:`int`
        Width of the port. The width of each of the attributes :py:`i`, :py:`o`, :py:`oe` (whenever
        present) equals :py:`width`.
    invert : :class:`bool` or iterable of :class:`bool`
        Polarity inversion. If the value is a simple :class:`bool`, it specifies inversion for
        the entire port. If the value is an iterable of :class:`bool`, the iterable must have the
        same length as the width of :py:`p` and :py:`n`, and the inversion is specified for
        individual wires.
    name : :class:`str` or :py:`None`
        Name of the port. This name is only used to derive the names of the input, output, and
        output enable signals.
    src_loc_at : :class:`int`
        :ref:`Source location <lang-srcloc>`. Used to infer :py:`name` if not specified.

    Attributes
    ----------
    invert : :class:`tuple` of :class:`bool`
        The :py:`invert` parameter, normalized to specify polarity inversion per-wire.
    direction : :class:`Direction`
        The :py:`direction` parameter, normalized to the :class:`Direction` enumeration.
    """
    def __init__(self, direction, width, *, invert=False, name=None, src_loc_at=0):
        if name is not None and not isinstance(name, str):
            raise TypeError(f"Name must be a string, not {name!r}")
        if name is None:
            name = tracer.get_var_name(depth=2 + src_loc_at, default="$port")

        if not (isinstance(width, int) and width >= 0):
            raise TypeError(f"Width must be a non-negative integer, not {width!r}")

        self._direction = Direction(direction)

        self._i_clk = self._i = self._o_clk = self._o = self._oe = None
        if self._direction in (io.Direction.Input, io.Direction.Bidir):
            self._i_clk = Signal(width, name=f"{name}__i_clk")
            self._i     = Signal(data.ArrayLayout(width, 2), name=f"{name}__i")
        if self._direction in (io.Direction.Output, io.Direction.Bidir):
            self._o_clk = Signal(width, name=f"{name}__o_clk")
            self._o     = Signal(data.ArrayLayout(width, 2), name=f"{name}__o")
            self._oe    = Signal(width, name=f"{name}__oe",
                                 init=~0 if self._direction is io.Direction.Output else 0)

        if isinstance(invert, bool):
            self._invert = (invert,) * width
        elif isinstance(invert, Iterable):
            self._invert = tuple(invert)
            if len(self._invert) != width:
                raise ValueError(f"Length of 'invert' ({len(self._invert)}) doesn't match "
                                 f"port width ({width})")
            if not all(isinstance(item, bool) for item in self._invert):
                raise TypeError(f"'invert' must be a bool or iterable of bool, not {invert!r}")
        else:
            raise TypeError(f"'invert' must be a bool or iterable of bool, not {invert!r}")

    @property
    def invert(self):
        return self._invert

    @property
    def direction(self):
        return self._direction

    def __len__(self):
        if self._direction is io.Direction.Input:
            return len(self._i)
        if self._direction is io.Direction.Output:
            assert len(self._o) == len(self._oe)
            return len(self._o)
        if self._direction is io.Direction.Bidir:
            assert len(self._i) == len(self._o) == len(self._oe)
            return len(self._i)
        assert False # :nocov:

    def __getitem__(self, key):
        result = object.__new__(type(self))
        result._i_clk = None if self._i_clk  is None else self._i_clk[key]
        result._i     = None if self._i      is None else self._i    [key]
        result._o_clk = None if self._o_clk  is None else self._o_clk[key]
        result._o     = None if self._o      is None else self._o    [key]
        result._oe    = None if self._oe     is None else self._oe   [key]
        if isinstance(key, slice):
            result._invert = self._invert[key]
        else:
            result._invert = (self._invert[key],)
        result._direction = self._direction
        return result

    def __invert__(self):
        result = object.__new__(type(self))
        result._i_clk = self._i_clk
        result._i     = self._i
        result._o_clk = self._o_clk
        result._o     = self._o
        result._oe    = self._oe
        result._invert = tuple(not invert for invert in self._invert)
        result._direction = self._direction
        return result

    def __add__(self, other):
        if not isinstance(other, MultiplexedPort):
            return NotImplemented
        direction = self._direction & other._direction
        result = object.__new__(type(self))
        result._i_clk = None if direction is io.Direction.Output else Cat(self._i_clk, other._i_clk)
        result._i     = None if direction is io.Direction.Output else Cat(self._i,     other._i)
        result._o_clk = None if direction is io.Direction.Input  else Cat(self._o_clk, other._o_clk)
        result._o     = None if direction is io.Direction.Input  else Cat(self._o,     other._o)
        result._oe    = None if direction is io.Direction.Input  else Cat(self._oe,    other._oe)
        result._invert = self._invert + other._invert
        result._direction = direction
        return result

    def __repr__(self):
        parts = []
        if self._i_clk is not None:
            parts.append(f"_i_clk={self._i_clk!r}")
        if self._i is not None:
            parts.append(f"_i={self._i!r}")
        if self._o_clk is not None:
            parts.append(f"_o_clk={self._o_clk!r}")
        if self._o is not None:
            parts.append(f"_o={self._o!r}")
        if self._oe is not None:
            parts.append(f"_oe={self._oe!r}")
        if not any(self._invert):
            invert = False
        elif all(self._invert):
            invert = True
        else:
            invert = self._invert
        return (f"MultiplexedPort({', '.join(parts)}, invert={invert!r}, "
                f"direction={self._direction})")


class PortSelector(wiring.Component):
    def __init__(self, main_port: io.PortLike, sub_ports: dict[int, MultiplexedPort]):
        assert count >= 0
        for key, sub_port in sub_ports.items():
            assert len(main_port) == len(sub_port)

        self._main_port = main_port
        self._sub_ports = sub_ports

        super().__init__({
            "select": range(max(sub_ports) + 1),
        })

    def elaborate(self, platform):
        m = Module()

        for index, main_port_bit in enumerate(self._main_port):
            m.domains[f"i_sync_{index}"] = ClockDomain(reset_less=True, local=True)
            m.domains[f"o_sync_{index}"] = ClockDomain(reset_less=True, local=True)
            m.submodules[f"buffer_{index}"] = buffer = io.DDRBuffer(
                main_port.direction, main_port[index],
                i_domain=f"i_sync_{index}", o_domain=f"o_sync_{index}")

        return m
